<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Paper Form</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <!-- Include jQuery from a CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container">
        
        <div class="row">
            <div class="col-md-6">
            <h1 class="mt-5 mb-4">Submit Your Paper</h1>
                <form method="post" action="process_paper.php" id="paperForm">
                    <div class="mb-3">
                        <label for="author" class="form-label">Author</label>
                        <input type="text" class="form-control" id="author" name="author" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="affiliate" class="form-label">Affiliate</label>
                        <input type="text" class="form-control" id="affiliate" name="affiliate" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Paper</button>
                    <button type="button" class="btn btn-secondary" id="cancelBtn">Cancel</button>
                </form>
            </div>

            <div class="col-md-6">
                <div id="additionalFields" style="display: none;">
                    <h2 class="mt-5 mb-4">Add Additional Details</h2>
                    <form action="process_paper.php" method="post">
                        <div class="mb-3">
                            <label for="typeOfPaper" class="form-label">Type of Paper</label>
                            <input type="text" class="form-control" id="typeOfPaper" name="typeOfPaper" required>
                        </div>
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="abstract" class="form-label">Abstract</label>
                            <textarea class="form-control" id="abstract" name="abstract" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit Paper</button>
                        <button type="button" class="btn btn-secondary" id="cancelAdditionalBtn">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Hide additional fields form by default
            $("#additionalFields").hide();

            $("#paperForm").submit(function(event) {
                event.preventDefault();

                var author = $("#author").val();
                var email = $("#email").val();
                var affiliate = $("#affiliate").val();

                $.ajax({
                    type: "POST",
                    url: "check_author.php", // PHP script to check if author exists
                    data: { author: author, email: email, affiliate: affiliate },
                    success: function(response) {
                        if (response == "exists") {
                            alert("Author details already registered!");
                        } else {
                            $("#additionalFields").show();
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("Error:", error);
                    }
                });
            });

            // Cancel additional fields form
            $("#cancelAdditionalBtn").click(function() {
                $("#additionalFields").hide();
            });

            // Cancel main form
            $("#cancelBtn").click(function() {
                $("#author").val("");
                $("#email").val("");
                $("#affiliate").val("");
            });
        });
    </script>
</body>
</html>
